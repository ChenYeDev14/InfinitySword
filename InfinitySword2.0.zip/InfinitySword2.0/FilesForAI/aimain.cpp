/*
ѡ�ֶ˳��� ����  ��׼ͨ��������

     ����������������ƽ̨������
     ��������������ӽӿڵķ�ʽ
##�뱣�ִ�������Ϊû�о����κ��޸ĵ�ԭ���׼������##
     ��������AI����ƽ̨���Ӵ�������и�

ѡ��ֻ��Ҫ��дInit��PlayerRun
*/


#pragma once



#include <cwchar>
#include <windows.h>
#include <iostream>
#include <ctime>
#include "Basic.h"
#include <string.h>
#include <stdlib.h>

using namespace DS14;
using namespace std;


void Init(PlayerInfo &playerInfo);
void PlayerRun();
void PlayerClear();

HANDLE hcontestt;

void CALLBACK TimerProc(HWND hwnd,UINT uMsg,UINT idEvent,DWORD dwTime);
DWORD CALLBACK Thread(PVOID pvoid);

int wmain(int argc, wchar_t * argv[])
{
	PlayerInfo playerInfo;
	LPWSTR lpFileName = new wchar_t [100];
    wcscpy(lpFileName, L"\\\\.\\pipe\\DS14") ;
	if (argc==2)
	{
		wcscat(lpFileName,argv[1]);
		wcscat(lpFileName,L"\\");
	}
    hcontestt = CreateFileW(lpFileName, GENERIC_WRITE|GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if( hcontestt == INVALID_HANDLE_VALUE )
	{
        cerr << "��ӭ�μӵ�ʮ�Ľ��ʽ������ƴ�����"<<endl << "��ʹ�ö�ʽƽ̨�򿪴˳���" << endl;
	}
	else 
	{
	    DWORD dwRead = 0, dwWritten = 0;
		WriteFile(hcontestt, (char*)&VERSION_BASIC, sizeof(int), &dwWritten, NULL);
        Init(playerInfo);
        WriteFile(hcontestt, (char*)&playerInfo, sizeof(playerInfo), &dwWritten, NULL);

		char* name = new char[20];
		wchar_t *WStr = L"string to convert";

		size_t len = wcslen(argv[1]) + 1;
		size_t converted = 0;
		name = (char*)malloc(len*sizeof(char));
		wcstombs_s(&converted, name, len, WStr, _TRUNCATE);

		for (int i=0; name[i] != '\0'; i++) if (name[i] == '-') { name[i] = '\0'; break;}
		HANDLE hFileMap = CreateFileMappingA((HANDLE)0xffffffff,NULL,
			PAGE_READWRITE, 0, 4 * 1024, name);
		LPBYTE pcMap = (LPBYTE)MapViewOfFile(hFileMap,FILE_MAP_READ|FILE_MAP_WRITE,
			0, 0, 0);

		HANDLE hThread = ::CreateThread(NULL,0,Thread,NULL,0,NULL);
		bool sus = false;
		while (true)
		{
			if (*pcMap == 'S' && !sus)
			{
				SuspendThread(hThread);
				sus = true;
			}
			else if (*pcMap == 'R' && sus) 
			{
				ResumeThread(hThread);
				sus = false;
			}
			else if (*pcMap == 'E') break;
			Sleep(1);
		}
		UnmapViewOfFile(pcMap);
		CloseHandle(hFileMap);
		CloseHandle(hThread);
		PlayerClear();
		delete name;
	}
	return 0;
}

GameInfo GetGameInfo()
{
	DWORD dwRead = 0, dwWritten = 0;
	char f = 'r';
	WriteFile(hcontestt, &f, sizeof(f), &dwWritten, NULL);
	GameInfo gInfo;
	while (!ReadFile(hcontestt, (char*)&gInfo, sizeof(gInfo), &dwRead, NULL));
	return gInfo;
}

void GiveCommand(const PlayerCommand &command)
{
	DWORD dwWritten = 0;
	char f = 'w';
	WriteFile(hcontestt, &f, sizeof(f), &dwWritten, NULL);
	WriteFile(hcontestt, (char*)&command, sizeof(command), &dwWritten, NULL);
}


DWORD CALLBACK Thread(PVOID pvoid)
{
	PlayerRun();
	return 0;
}