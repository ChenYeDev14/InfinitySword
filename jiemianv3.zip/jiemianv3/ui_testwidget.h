/********************************************************************************
** Form generated from reading UI file 'testwidget.ui'
**
** Created: Tue Oct 23 22:45:13 2012
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TESTWIDGET_H
#define UI_TESTWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TestWidget
{
public:
    QPushButton *pushButton;
    QLineEdit *lineEdit;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QPushButton *pushButton_9;
    QPushButton *pushButton_10;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;
    QLabel *label;
    QLabel *label_2;

    void setupUi(QWidget *TestWidget)
    {
        if (TestWidget->objectName().isEmpty())
            TestWidget->setObjectName(QString::fromUtf8("TestWidget"));
        TestWidget->resize(1024, 768);
        pushButton = new QPushButton(TestWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(30, 690, 141, 31));
        lineEdit = new QLineEdit(TestWidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(200, 50, 250, 31));
        pushButton_2 = new QPushButton(TestWidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(30, 50, 141, 31));
        pushButton_3 = new QPushButton(TestWidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(630, 210, 141, 31));
        pushButton_4 = new QPushButton(TestWidget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(680, 260, 141, 31));
        pushButton_5 = new QPushButton(TestWidget);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(570, 310, 141, 31));
        pushButton_6 = new QPushButton(TestWidget);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(500, 360, 141, 31));
        pushButton_7 = new QPushButton(TestWidget);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(680, 460, 141, 31));
        pushButton_8 = new QPushButton(TestWidget);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setGeometry(QRect(590, 510, 141, 31));
        pushButton_9 = new QPushButton(TestWidget);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setGeometry(QRect(610, 410, 141, 31));
        pushButton_10 = new QPushButton(TestWidget);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
        pushButton_10->setGeometry(QRect(510, 560, 141, 31));
        pushButton_11 = new QPushButton(TestWidget);
        pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));
        pushButton_11->setGeometry(QRect(580, 610, 141, 31));
        pushButton_12 = new QPushButton(TestWidget);
        pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));
        pushButton_12->setGeometry(QRect(650, 660, 141, 31));
        label = new QLabel(TestWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 240, 151, 371));
        label->setStyleSheet(QString::fromUtf8("border-image: url(:/image/form.png);"));
        label_2 = new QLabel(TestWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(30, 150, 151, 51));
        label_2->setStyleSheet(QString::fromUtf8("border-image: url(:/image/title.png);"));

        retranslateUi(TestWidget);

        QMetaObject::connectSlotsByName(TestWidget);
    } // setupUi

    void retranslateUi(QWidget *TestWidget)
    {
        TestWidget->setWindowTitle(QApplication::translate("TestWidget", "TestWidget", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("TestWidget", "\347\246\273\345\274\200", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("TestWidget", "\350\275\275\345\205\245AI", 0, QApplication::UnicodeUTF8));
        pushButton_3->setText(QApplication::translate("TestWidget", "\347\254\254\345\215\201\345\205\263", 0, QApplication::UnicodeUTF8));
        pushButton_4->setText(QApplication::translate("TestWidget", "\347\254\254\344\271\235\345\205\263", 0, QApplication::UnicodeUTF8));
        pushButton_5->setText(QApplication::translate("TestWidget", "\347\254\254\345\205\253\345\205\263", 0, QApplication::UnicodeUTF8));
        pushButton_6->setText(QApplication::translate("TestWidget", "\347\254\254\344\270\203\345\205\263", 0, QApplication::UnicodeUTF8));
        pushButton_7->setText(QApplication::translate("TestWidget", "\347\254\254\345\205\255\345\205\263", 0, QApplication::UnicodeUTF8));
        pushButton_8->setText(QApplication::translate("TestWidget", "\347\254\254\344\272\224\345\205\263", 0, QApplication::UnicodeUTF8));
        pushButton_9->setText(QApplication::translate("TestWidget", "\347\254\254\345\233\233\345\205\263", 0, QApplication::UnicodeUTF8));
        pushButton_10->setText(QApplication::translate("TestWidget", "\347\254\254\344\270\211\345\205\263", 0, QApplication::UnicodeUTF8));
        pushButton_11->setText(QApplication::translate("TestWidget", "\347\254\254\344\272\214\345\205\263", 0, QApplication::UnicodeUTF8));
        pushButton_12->setText(QApplication::translate("TestWidget", "\347\254\254\344\270\200\345\205\263", 0, QApplication::UnicodeUTF8));
        label->setText(QString());
        label_2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class TestWidget: public Ui_TestWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TESTWIDGET_H
