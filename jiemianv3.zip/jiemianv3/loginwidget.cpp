#include "loginwidget.h"
#include "ui_loginwidget.h"
#include <QPainter>
#include <QPalette>
#include <QMessageBox>

#include <QCryptographicHash>
#include <QtNetwork/QNetworkRequest>
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkReply>

LogInWidget::LogInWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LogInWidget)
{
    db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("166.111.223.20");
    db.setDatabaseName("team14");
    db.setUserName("team14");
    db.setPassword("duishi14_2012");

    ui->setupUi(this);
    QPalette pe;
    pe.setColor(QPalette::WindowText,Qt::white);
    ui->label->setPalette(pe);
    ui->label_2->setPalette(pe);
    connect(ui->pushButton_login,SIGNAL(clicked()),this,SLOT(LogIn()));
}

LogInWidget::~LogInWidget()
{
    delete ui;
}


void LogInWidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.drawPixmap(0,0,1024,768,QPixmap(":/image/logIn.png"));
}

Ui::LogInWidget* LogInWidget::returnUi()
{
    return ui;
}


void LogInWidget::LogIn()
{
    QString id;
    if (db.open())
    {
        user_name = ui->lineEdit_user->text();
        //�����ݿ���û�id
        QSqlQuery query(db);
        QString exe = "SELECT id FROM user WHERE email = '" + user_name +"'";
        query.exec(exe);
        if (query.next())
        {
            ui->pushButton_login->setEnabled(false);
            id = query.value(0).toString();
            //ת��sha1
            QByteArray data=ui->lineEdit_code->text().toAscii();
            QCryptographicHash *hash=new QCryptographicHash(QCryptographicHash::Sha1);
            hash->addData(data);
            QByteArray sha1=hash->result();
            char *c = sha1.toHex().data();
            std::string string_sha1(c);
            //����һ������
            QNetworkRequest request;
            QString url = "http://duishi.eekexie.org/index.php/management/login_query?id="+id+"&pwd=";
            url += QString::fromStdString(string_sha1);
            request.setUrl(QUrl(url));
            //����һ��������
            QNetworkAccessManager *manager = new QNetworkAccessManager(this);
            //����GET����
            reply = manager->get(request);
            connect(reply, SIGNAL(readyRead()), this, SLOT(http_request_ready_read()));

        }
        else
        {
            QMessageBox box;
            box.setWindowTitle(tr("����"));
            box.setIcon(QMessageBox::Warning);
            box.setText(tr("�û������󣡣�������ע�����䣩"));
            box.setStandardButtons(QMessageBox::Ok);
            box.exec();
            return;
        }
    }
    else
    {
        QMessageBox box;
        box.setWindowTitle(tr("����"));
        box.setIcon(QMessageBox::Warning);
        box.setText(tr("���ӷ�����ʧ�ܣ�������������"));
        box.setStandardButtons(QMessageBox::Ok);
        box.exec();
        return;
    }
}

void LogInWidget::http_request_ready_read()
{
    char result;
    reply->read(&result, sizeof(char));
    if (result == '1')
    {
        emit login_success(user_name);
    }
    else
    {
        QMessageBox box;
        box.setWindowTitle(tr("����"));
        box.setIcon(QMessageBox::Warning);
        box.setText(tr("�������"));
        box.setStandardButtons(QMessageBox::Ok);
        box.exec();
    }
    ui->pushButton_login->setEnabled(true);
}
