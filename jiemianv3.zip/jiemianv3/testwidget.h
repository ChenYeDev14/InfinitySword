#ifndef TESTWIDGET_H
#define TESTWIDGET_H

#include <QWidget>
#include <QPaintEvent>
#include <QPushButton>
#include "ui_testwidget.h"
#include<QtSql/qsqldatabase.h>
#include<QtSql/qsqlerror.h>
#include<QtSql/qsqlquery.h>

namespace Ui {
class TestWidget;
}

class TestWidget : public QWidget
{
    Q_OBJECT
    
public:
    explicit TestWidget(QWidget *parent = 0);
    ~TestWidget();
    QPushButton* but[10];
    Ui::TestWidget* returnUi();
    void SetUserName(QString user) {user_name = user;}

private:
    Ui::TestWidget *ui;
    void paintEvent(QPaintEvent *);
    void upDateScores();
    QString user_name;
    QSqlDatabase db;
    int scores[10];

};

#endif // TESTWIDGET_H
