/****************************************************************************
** Meta object code from reading C++ file 'widgetssingle.h'
**
** Created: Tue Oct 23 22:46:02 2012
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../widgetssingle.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'widgetssingle.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_widgetssingle[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      15,   14,   14,   14, 0x08,
      28,   14,   14,   14, 0x08,
      40,   14,   14,   14, 0x08,
      49,   14,   14,   14, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_widgetssingle[] = {
    "widgetssingle\0\0playervsai()\0levelmode()\0"
    "replay()\0mapedit()\0"
};

void widgetssingle::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        widgetssingle *_t = static_cast<widgetssingle *>(_o);
        switch (_id) {
        case 0: _t->playervsai(); break;
        case 1: _t->levelmode(); break;
        case 2: _t->replay(); break;
        case 3: _t->mapedit(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData widgetssingle::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject widgetssingle::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_widgetssingle,
      qt_meta_data_widgetssingle, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &widgetssingle::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *widgetssingle::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *widgetssingle::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_widgetssingle))
        return static_cast<void*>(const_cast< widgetssingle*>(this));
    return QWidget::qt_metacast(_clname);
}

int widgetssingle::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
