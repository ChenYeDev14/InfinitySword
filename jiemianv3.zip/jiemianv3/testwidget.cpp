#include "testwidget.h"
#include "ui_testwidget.h"
#include <QPainter>

#include <QCryptographicHash>
#include <QtNetwork/QNetworkRequest>
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkReply>


TestWidget::TestWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::TestWidget)
{
    db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("166.111.223.20");
    db.setDatabaseName("team14");
    db.setUserName("team14");
    db.setPassword("duishi14_2012");

    upDateScores();

    ui->setupUi(this);
    but[0] = ui->pushButton_3;
    but[1] = ui->pushButton_4;
    but[2] = ui->pushButton_5;
    but[3] = ui->pushButton_6;
    but[4] = ui->pushButton_7;
    but[5] = ui->pushButton_8;
    but[6] = ui->pushButton_9;
    but[7] = ui->pushButton_10;
    but[8] = ui->pushButton_11;
    but[9] = ui->pushButton_12;
    for ( int i = 0 ; i < 9 ; i++ ){
        but[i]->move(but[9]->x(),but[9]->y());
    }
}

TestWidget::~TestWidget()
{
    delete ui;
}

void TestWidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.drawPixmap(0,0,1024,768,QPixmap(":/image/logIn.png"));
}

Ui::TestWidget* TestWidget::returnUi()
{
    return ui;
}

void TestWidget::upDateScores()
{
    if (!db.open()) return;
    for (int i=1; i<=10; i++)
    {
        QSqlQuery query(db);
        QString column = "test_" + QString::number(i);
        QString exe = "SELECT "+column+" FROM user WHERE email = '"+user_name+"'";
        query.exec(exe);
        if (query.next())
            scores[i-1] = query.value(0).toInt();
    }
    db.close();
}


