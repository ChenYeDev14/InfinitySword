#ifndef DATABASE_H
#define DATABASE_H

#define HOST_NAME "166.111.223.20"
#define DATABASE_NAME "team14"
#define USER_NAME "team14"
#define PASSWORD "duishi14_2012"


#endif // DATABASE_H

